package com.example.firebase

// on below line creating a data class for course,
data class Data(
    // on below line creating variables.
    var Name: String,
    var Surname: String,
    var Email: String,
    var Birthday: String
)